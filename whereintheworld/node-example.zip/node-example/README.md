Implementation:
As far as I know, everything has been correctly implemented.

Help With Assignment From:
Ming

Hours Spent:
7 hours approximately

