// Express initialization
var express = require('express');
var bodyParser = require('body-parser');
var validator = require('validator'); // See documentation at https://github.com/chriso/validator.js
var async = require('async');
var app = express();
// See https://stackoverflow.com/questions/5710358/how-to-get-post-query-in-express-node-js
app.use(bodyParser.json());
// See https://stackoverflow.com/questions/25471856/express-throws-error-as-body-parser-deprecated-undefined-extended
app.use(bodyParser.urlencoded({ extended: true }));
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/whereintheworld'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
});

app.get('/', function (request, response) {
  	response.set('Content-Type', 'text/html');
  	db.collection('locations', function(er, collection) {
		if (er) {
			response.send("Can't get locations");
		}
		else {	
			collection.find().sort({'created_at':-1}).toArray(function(err, cursor) {
				var numLogins = cursor.length;
				var checkins = "";

				async.eachSeries(cursor, function(userData, callback){

					var login = userData['login'];
					var timestamp = userData['created_at'];
					var lat = userData['lat'];
					var lng = userData['lng'];

					//get address from lat + lng, using reverse geolocation Google API
					var xhr = new XMLHttpRequest();
					var reverseGeo = "http://maps.googleapis.com/maps/api/geocode/json?latlng=" + lat + "," + lng + "&sensor=true";

					xhr.open("GET", reverseGeo, true);

					xhr.onreadystatechange = function(){
						if (xhr.readyState === 4) {
							if (xhr.status === 200) {
								address = (JSON.parse(xhr.responseText)['results'][0]['formatted_address']);
								checkins += "<p>" + login + " logged in at " + timestamp + " at address " + address + "</p>";
								callback();
							}
						}
					}

					xhr.send(null);

					}, function(err){
						if (err) 
							response.send("whoops something went terribly wrong");
						else{
							response.send(checkins);
						}
					}

				) //ends async call
			});
		}
	});
});

app.post('/sendLocation', function(request, response) {

	var login = request.body.login;
	var lat = request.body.lat;
	var lng = request.body.lng;

	if (!login || !lat || !lng) {
		response.send("whoops, something went terribly wrong");
	};

	var toInsert = {
		"login": login,
		"lat": parseFloat(lat),
		"lng": parseFloat(lng),
		"created_at": Date()
	};
	db.collection('locations', function(er, collection) {
		var id = collection.insert(toInsert, function(err, saved) {
			if (err) {
				response.send(500);
			}
			else {
				collection.find().sort({'created_at':-1}).limit(100).toArray(function(err, arr){
					if (err) {
						response.send("something went terribly wrong");
					}
					else {
						response.set('Content-Type', 'application/json');
						var jsonResponse = {"characters": [], 
											"students"  : arr};
						response.send(jsonResponse);
					}
				});

			}
	    });
	});
});

app.get('/locations.json', function(request, response) {
	//put locs from response, into an array
	var login = request.query.login;
	if (!login){
		response.send([]);
	}
	db.collection('locations', function(er, collection) {
		if (er) {
			response.send([]);
		}
		else {	
			collection.find({"login": login}).sort({'created_at':-1}).toArray(function(err, cursor) {
				response.send(cursor);
			});
		}
	});


});

app.get('/redline.json', function(request, response) {
	response.set('Content-Type', 'application/json');
	var xhr = new XMLHttpRequest();
	xhr.open("GET", "http://developer.mbta.com/lib/rthr/red.json", true);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

	xhr.onreadystatechange = function(){
		if (xhr.readyState === 4) {
			if (xhr.status === 200) {
				response.send(xhr.responseText);
			}
		}
	}
	xhr.send(null);

});

app.listen(process.env.PORT || 3000);